package com.dakr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendorDetailsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendorDetailsAppApplication.class, args);
	}

}
